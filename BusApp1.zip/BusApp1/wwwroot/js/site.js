﻿// site.js

document.addEventListener('DOMContentLoaded', function () {
    // Fonction pour confirmer la suppression d'un élément
    document.querySelectorAll('.delete-button').forEach(function (button) {
        button.addEventListener('click', function (event) {
            if (!confirm('Voulez-vous vraiment supprimer cet élément ?')) {
                event.preventDefault();
            }
        });
    });

    // Fonction pour valider les formulaires avant soumission
    document.querySelectorAll('form').forEach(function (form) {
        form.addEventListener('submit', function (event) {
            if (!validateForm(form)) {
                event.preventDefault();
            }
        });
    });

    function validateForm(form) {
        // Ajoutez vos validations de formulaire ici
        return true; // Retournez false si le formulaire n'est pas valide
    }
});
