﻿namespace BusApp.Models
{
    public class Arrêt
    {
        public int Id { get; set; }
        public string Nom { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }
    }
}
