﻿using System.ComponentModel.DataAnnotations;

namespace BusApp.Models
{
    public class Ligne
    {
        public int Id { get; set; }

        [Required]
        public string Nom { get; set; }

        [Required]
        public string Numéro { get; set; }
    }
}
