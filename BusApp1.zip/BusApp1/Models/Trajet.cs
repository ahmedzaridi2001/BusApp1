﻿using System;
using System.ComponentModel.DataAnnotations;

namespace BusApp.Models
{
    public class Trajet
    {
        public int Id { get; set; }

        [Required]
        public int LigneId { get; set; }

        [Required]
        public int ArrêtDépartId { get; set; }

        [Required]
        public int ArrêtArrivéeId { get; set; }

        [Required]
        public DateTime HeureDépart { get; set; }

        [Required]
        public DateTime HeureArrivée { get; set; }

        // Relations (facultatif, selon vos besoins)
        public Ligne? Ligne { get; set; }
        public Arrêt? ArrêtDépart { get; set; }
        public Arrêt? Arrivée { get; set; }
    }
}
