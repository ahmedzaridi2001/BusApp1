﻿using Microsoft.EntityFrameworkCore;
using BusApp.Models; 
using System.Collections.Generic;

namespace BusApp.Data
{
    public class BusManagementContext : DbContext
    {
        public BusManagementContext(DbContextOptions<BusManagementContext> options)
            : base(options)
        {
        }

        public DbSet<Arrêt> Arrêts { get; set; }
        public DbSet<Ligne> Lignes { get; set; }
        public DbSet<Trajet> Trajets { get; set; } 
    }
}
