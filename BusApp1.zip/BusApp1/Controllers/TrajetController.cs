﻿using Microsoft.AspNetCore.Mvc;
using BusApp.Data;
using BusApp.Models;
using System.Threading.Tasks;

namespace BusApp.Controllers
{
    public class TrajetController : Controller
    {
        private readonly BusManagementContext _context;

        public TrajetController(BusManagementContext context)
        {
            _context = context;
        }

        // GET: Trajet/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Trajet/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("LigneId,ArrêtDépartId,ArrêtArrivéeId,HeureDépart,HeureArrivée")] Trajet trajet)
        {
            if (ModelState.IsValid)
            {
                _context.Add(trajet);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(trajet);
        }
    }
}