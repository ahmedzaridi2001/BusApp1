﻿using Microsoft.AspNetCore.Mvc;
using BusApp.Data; // Assurez-vous que le namespace est correct pour votre contexte
using BusApp.Models; // Assurez-vous que le namespace est correct pour vos modèles
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace BusApp.Controllers // Assurez-vous que cet espace de noms est correct
{
    public class ArrêtController : Controller
    {
        private readonly BusManagementContext _context;

        public ArrêtController(BusManagementContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            var arrêts = await _context.Arrêts.ToListAsync();
            return View(arrêts);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Nom,Latitude,Longitude")] Arrêt arrêt)
        {
            if (ModelState.IsValid)
            {
                _context.Add(arrêt);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(arrêt);
        }
    }
}
