﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BusApp.Data;
using BusApp.Models;
using System.Threading.Tasks;
using System.Linq;

namespace BusApp.Controllers
{
    public class LigneController : Controller
    {
        private readonly BusManagementContext _context;

        public LigneController(BusManagementContext context)
        {
            _context = context;
        }

        // GET: Ligne/Index
        public async Task<IActionResult> Index()
        {
            return View(await _context.Lignes.ToListAsync());
        }

        // GET: Ligne/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var ligne = await _context.Lignes
                .FirstOrDefaultAsync(m => m.Id == id);

            if (ligne == null)
            {
                return NotFound();
            }

            return View(ligne);
        }

        // GET: Ligne/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Ligne/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Nom,Description")] Ligne ligne)
        {
            if (ModelState.IsValid)
            {
                _context.Add(ligne);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(ligne);
        }

        // GET: Ligne/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var ligne = await _context.Lignes.FindAsync(id);
            if (ligne == null)
            {
                return NotFound();
            }
            return View(ligne);
        }

        // POST: Ligne/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Nom,Description")] Ligne ligne)
        {
            if (id != ligne.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(ligne);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!LigneExists(ligne.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(ligne);
        }

        // GET: Ligne/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var ligne = await _context.Lignes
                .FirstOrDefaultAsync(m => m.Id == id);

            if (ligne == null)
            {
                return NotFound();
            }

            return View(ligne);
        }

        // POST: Ligne/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var ligne = await _context.Lignes.FindAsync(id);

            if (ligne != null)
            {
                _context.Lignes.Remove(ligne);
                await _context.SaveChangesAsync();
            }

            return RedirectToAction(nameof(Index));
        }

        private bool LigneExists(int id)
        {
            return _context.Lignes.Any(e => e.Id == id);
        }
    }
}
